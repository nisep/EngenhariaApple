package br.inatel.ec206.administrador;

import static org.junit.Assert.*;

import org.junit.Test;

public class Testes {

	@Test
	public void Nome() {
		
		Administrador administrador = new Administrador("", 20, "123.456.789-00", 1000.5, 6);
		assertEquals("Invalido", administrador.getNome());
			
		administrador.setNome("Bianca");
		assertEquals("Bianca", administrador.getNome());
		
		administrador.setNome("");
		assertEquals("Invalido", administrador.getNome());
		
		administrador.setNome(null);
		assertEquals("Invalido", administrador.getNome());

		Administrador administrador2 = new Administrador(null, 20, "123.456.789-00", 1000.5, 6);
		assertEquals("Invalido", administrador2.getNome());
	}
	
	@Test
	public void Idade() {
		
		Administrador administrador = new Administrador("Bianca", 20, "123.456.789-00", 1000.5, 6);
		assertEquals(20, administrador.getIdade());
			
		administrador.setIdade(-1);
		assertEquals(0, administrador.getIdade());
		
		Administrador administrador2 = new Administrador("Bianca", -10, "123.456.789-00", 1000.5, 6);
		assertEquals(0, administrador2.getIdade());

	}
	
	@Test
	public void CPF() {
		
		Administrador administrador = new Administrador("Bianca", 20, "123.456.789-00", 1000.5, 6);
		assertEquals("123.456.789-00", administrador.getCpf());
			
		administrador.setCpf("123.456.789-004");
		assertEquals("Invalido", administrador.getCpf());
		
		Administrador administrador2 = new Administrador("Bianca", 20, "123.456.789-0000", 1000.5, 6);
		assertEquals("Invalido", administrador.getCpf());
		
		administrador.setCpf("123.456.789-00");
		assertEquals("123.456.789-00", administrador.getCpf());
	}
	
	@Test
	public void Salario() {
		
		Administrador administrador = new Administrador("Bianca", 20, "123.456.789-00", -1, 6);
		assertEquals(0, administrador.getSalario(), 0.01);
			
		administrador.setSalario(100);
		assertEquals(100, administrador.getSalario(), 0.01);
		
		administrador.setSalario(-100);
		assertEquals(0, administrador.getSalario(), 0.01);
		
		Administrador administrador2 = new Administrador("Bianca", 20, "123.456.789-00", 1000.6, 6);
		assertEquals(1000.6, administrador2.getSalario(), 0.01);
	}

	@Test
	public void TempoTrabalho() {
		
		Administrador administrador = new Administrador("Bianca", 20, "123.456.789-00", -1, 6);
		assertEquals(6, administrador.getTempoTrabalho());
			
		administrador.setTempoTrabalho(-1);
		assertEquals(0, administrador.getTempoTrabalho());
		
		Administrador administrador2 = new Administrador("Bianca", 20, "123.456.789-00", -1, -10);
		assertEquals(0, administrador2.getTempoTrabalho());
			
		administrador2.setTempoTrabalho(10);
		assertEquals(10, administrador2.getTempoTrabalho());
	}
	
	@Test
	public void ReajusteSalario() {
		
		Administrador administrador = new Administrador("Bianca", 20, "123.456.789-00", 100, 6);
		administrador.reajusteDeSalario(10);
		assertEquals(110, administrador.getSalario(), 0.01);
		administrador.reajusteDeSalario(-5);
		assertEquals(110, administrador.getSalario(), 0.01);
	}
	
	@Test
	public void TempoTrabalhado() {
		
		Administrador administrador = new Administrador("Bianca", 20, "123.456.789-00", 100, 6);
		assertEquals(6, administrador.tempoTrabalhado(2017));
		assertEquals(0, administrador.tempoTrabalhado(1000));
	}
}
