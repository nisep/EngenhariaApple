package br.inatel.ec206.administrador;

import java.util.Calendar;

/**
 * @author 	Daniel Izario
 * @version 1.0
 * @since   2017
 */

public class Administrador extends Exception{

	/*
		Objetivo: Voc�s ter�o de testar esta classe usando o Junit do eclipse, 
		durante os testes voc�s ter�o que tratar os erros. Os erros acontecem 
		quando voc� insere dados que n�o s�o poss�veis de ocorrer, tais como:
		nomes em branco, n�meros negativos em alguns campos, cpfs inv�lidos etc.
	*/
	
	private String nome;	// nome do administrador
	private int idade;		// idade do adiministrador
	private String cpf;		// cpf do administrador
	private double salario;	// salario recebido por ele
	private int anoAdmicao;	// ano em que entrou na empresa

	// Todos os campos s�o obrigat�rios!
	public Administrador(String nome, int idade, String cpf, double salario, int tempoTrabalho){
		
		try {
			if(nome.length() == 0 || nome == null){
				nome = "Invalido";
			}
		
		} catch (Exception e) {
			System.out.println("Erro");
			nome = "Invalido";
		}
			
		if(idade<0){
			idade = 0;
		}
		
		//XXX.XXX.XXX-XX
		if(cpf.length()>14){
			cpf = "Invalido";
		}
		
		if(salario < 0){
			salario = 0;
		}
		
		if(tempoTrabalho<0){
			tempoTrabalho = 0;
		}
		
		this.nome = nome;
		this.idade = idade;
		this.cpf = cpf;
		this.salario = salario;
		this.anoAdmicao = 2017 - tempoTrabalho;
		
	}

	// M�todos Getters and Setters!
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		try {
			if(nome.length()==0 || nome==null){
				nome="Invalido";
			}
			
			this.nome = nome;
		} catch (Exception e) {
			System.out.println("Erro");
		}
		
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		if(idade<0){
			idade=0;
		}
		this.idade = idade;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		if(cpf.length()>14){
			cpf = "Invalido";
		}
		this.cpf = cpf;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		if(salario < 0){
			salario = 0;
		}
		this.salario = salario;
	}

	public int getTempoTrabalho() {
		return 2017 - anoAdmicao;
	}

	public void setTempoTrabalho(int tempoTrabalho) {
		if(tempoTrabalho<0){
			tempoTrabalho = 0;
		}
		this.anoAdmicao = 2017 - tempoTrabalho;
	}

	// M�todos!
	public boolean reajusteDeSalario(double porcentagem) {
		double salario = 0;
		if(porcentagem<0){
			porcentagem = 0;
		}
		salario = this.salario;
		salario += ((salario * porcentagem) / 100);
		this.setSalario(salario);
		return true;
	}

	public int tempoTrabalhado(int dataAtual) {
		int tempo = 0;	// Tempo dado em anos!
		if(dataAtual<anoAdmicao){
			dataAtual = anoAdmicao;
		}
		tempo = dataAtual - anoAdmicao;
		return tempo;
	}
}

/**
 * @reference	
 */