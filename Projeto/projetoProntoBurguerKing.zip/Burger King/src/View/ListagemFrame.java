package View;

import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

import Model.Bebida;
import Model.BebidaDAO;
import Model.Combo;
import Model.ComboDAO;
import Model.Lanche;
import Model.LancheDAO;
import Model.Promocao;
import Model.PromocaoDAO;
import Model.Sobremesa;
import Model.SobremesaDAO;
import Model.Usuario;
import Model.UsuarioDAO;

public class ListagemFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	
	private URL UrlBackground;
	private Image Background;
	
	private Boolean ADM;
	private int CATEGORIA;
	@SuppressWarnings("unused")
	private int CRUD;
	
	private JTextArea TextArea;

	private JButton VoltarButton;
	
	private Font Fonte25 = new Font("SansSerif", Font.PLAIN, 30);
	
	private BebidaDAO bebidaDAO = new BebidaDAO("Bebidas.txt");
	private ComboDAO comboDAO = new ComboDAO("Combos.txt");
	private LancheDAO lancheDAO = new LancheDAO("Lanches.txt");
	private PromocaoDAO promocaoDAO = new PromocaoDAO("Promocoes.txt");
	private SobremesaDAO sobremesaDAO = new SobremesaDAO("Sobremesas.txt");
	private UsuarioDAO usuarioDAO = new UsuarioDAO("Usuarios.txt");
	
	private ArrayList<Bebida> bebidas;
	private ArrayList<Combo> combos;
	private ArrayList<Lanche> lanches;
	private ArrayList<Promocao> promocoes;
	private ArrayList<Sobremesa> sobremesas;
	private ArrayList<Usuario> usuarios;
	
	/*    CRUD
	 * 1 => Cadastro
	 * 2 => Editar
	 * 3 => Excluir
	 * 4 => Buscar
	 * 5 => Listar
	 * 6 => Gerar Relat�rio*/
	
	/*  CATEGORIA
	 * 1 => Usuario
	 * 2 => Lanches
	 * 3 => Sobremesa
	 * 4 => Bebida
	 * 5 => Combo
	 * 6 => Promocao */
	
	public ListagemFrame(boolean ADM, int CRUD, int CATEGORIA) {
		super();
		
		this.ADM = ADM;
		this.CRUD = CRUD;
		this.CATEGORIA = CATEGORIA;
		
		setSize(1200, 700);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setTitle("Listagem - Burger King");
		setResizable(false);
		setVisible(true);
		
		UrlBackground = getClass().getResource("Background.png");
		Background = Toolkit.getDefaultToolkit().getImage(UrlBackground);
	    JLabel background = new JLabel(new ImageIcon(Background));
	    background.setBounds(0, 0, 1200, 700);
	    
	    add(getTextArea());
	    add(getVoltarButton());
	    
	    add(background);
	}
	
	
	public JTextArea getTextArea() {
		if(TextArea == null){
			
			String texto = "  LISTA DE ";
			
			TextArea = new JTextArea();
			TextArea.setVisible(true);
			TextArea.setBounds(100, 50, 400, 600);
			TextArea.setLineWrap(true);
			TextArea.setEditable(false);
			TextArea.setBorder(null);
			TextArea.setOpaque(false);
			TextArea.setFont(Fonte25);
			
			if(CATEGORIA == 1 && ADM == false) {  //Usu�rios sem permiss�o
				JOptionPane.showMessageDialog(null, "Voc� n�o possui permiss�o para isto !" ,"Listagem - Burger King",JOptionPane.WARNING_MESSAGE);
			}
			if(CATEGORIA == 1 && ADM == true) {  //Usuarios
				texto += "USU�RIOS\n\n\n";
				usuarios = usuarioDAO.read();
				for(Usuario usuario : usuarios) {texto += usuario.getNome() + "\n\n"; }
			}
			if(CATEGORIA == 2) {  //Lanches
				texto += "LANCHES\n\n\n";
				lanches = lancheDAO.read();
				for(Lanche lanche : lanches) { texto += lanche.getNome() + "\n\n";}
			}
			if(CATEGORIA == 3) {  //Sobremesas
				texto += "SOBREMESAS\n\n\n";
				sobremesas = sobremesaDAO.read();
				for(Sobremesa sobremesa : sobremesas) { texto += sobremesa.getNome() + "\n\n";}
			}
			if(CATEGORIA == 4) {  //Bebidas
				texto += "BEBIDAS\n\n\n";
				bebidas = bebidaDAO.read();
				for(Bebida bebida : bebidas) { texto += bebida.getNome() + "\n\n";}
			}
			if(CATEGORIA == 5) {  //Combos
				texto += "COMBOS\n\n\n";
				combos = comboDAO.read();
				for(Combo combo : combos) { texto += combo.getNome() + "\n\n";}
			}
			if(CATEGORIA == 6) {  //Promocoes
				texto += "PROMOCOES\n\n\n";
				promocoes = promocaoDAO.read();
				for(Promocao promocao : promocoes) { texto += promocao.getNome() + "\n\n";}
			}
			
			TextArea.setText(texto);			
		}
		return TextArea;
	}
	
	
	public JButton getVoltarButton() {
		if(VoltarButton == null){
			VoltarButton = new JButton("Voltar");
			VoltarButton.setBounds(1000, 20, 150, 30);
			
			VoltarButton.addActionListener(new ActionListener() {				
				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
					@SuppressWarnings("unused") 
					MenuFrame menuFrame = new MenuFrame(ADM);
				}
			});
		}
		return VoltarButton;
	}

}