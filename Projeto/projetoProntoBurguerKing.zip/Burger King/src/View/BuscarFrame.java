package View;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import Control.ButtonsListener;

public class BuscarFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	
	private URL UrlBackground;
	private Image Background;
	
	private Boolean ADM;
	private int CATEGORIA;
	private int CRUD;
	
	private JTextField nomeField;
	private JLabel nomeLabel;
	
	private JTextArea TextArea;

	private JButton confirmButton;
	private JButton VoltarButton;
	
	private ButtonsListener buttonsListener = new ButtonsListener();
	
	private Font Fonte25 = new Font("SansSerif", Font.PLAIN, 30);
	
	/*    CRUD
	 * 1 => Cadastro
	 * 2 => Editar
	 * 3 => Excluir
	 * 4 => Buscar
	 * 5 => Listar
	 * 6 => Gerar Relat�rio*/
	
	/*  CATEGORIA
	 * 1 => Usuario
	 * 2 => Lanches
	 * 3 => Sobremesa
	 * 4 => Bebida
	 * 5 => Combo
	 * 6 => Promocao */
	
	public BuscarFrame(boolean ADM, int CRUD, int CATEGORIA) {
		super();
		
		this.ADM = ADM;
		this.CRUD = CRUD;
		this.CATEGORIA = CATEGORIA;
		
		setSize(1200, 700);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setTitle("Busca - Burger King");
		setResizable(false);
		setVisible(true);
		
		UrlBackground = getClass().getResource("Background.png");
		Background = Toolkit.getDefaultToolkit().getImage(UrlBackground);
	    JLabel background = new JLabel(new ImageIcon(Background));
	    background.setBounds(0, 0, 1200, 700);
	    
	    add(getnomeField());
	    add(getNomeLabel());
	    add(getConfirmButton());
	    add(getTextArea());
	    add(getVoltarButton());
	    
	    add(background);
	}
	
	
	public JTextArea getTextArea() {
		if(TextArea == null){
			
			TextArea = new JTextArea();
			TextArea.setVisible(true);
			TextArea.setBounds(100, 200, 450, 400);
			TextArea.setLineWrap(true);
			TextArea.setEditable(false);
			TextArea.setBorder(null);
			TextArea.setOpaque(false);
			TextArea.setFont(Fonte25);
		}
		return TextArea;
	}
	
	
	public JTextField getnomeField(){
		if(nomeField == null) {
			nomeField = new JTextField();
			nomeField.setFont(Fonte25);
			nomeField.setBounds(80, 100, 400, 50);
		}
		return nomeField;
	}
	
	public JLabel getNomeLabel() {
		if(nomeLabel == null){
			nomeLabel = new JLabel("Nome:");
			nomeLabel.setForeground(Color.BLACK);
			nomeLabel.setVisible(true);
			nomeLabel.setFont(Fonte25);
			nomeLabel.setBounds(80, 50, 100, 40);
		}
		return nomeLabel;
	}
	
	
	public JButton getConfirmButton(){
		if(confirmButton == null){
			confirmButton = new JButton();
			if(CRUD == 2) confirmButton.setText("Editar");
			if(CRUD == 3) confirmButton.setText("Excluir");
			if(CRUD == 4) confirmButton.setText("Buscar");
			confirmButton.setFont(Fonte25);
			confirmButton.setBounds(140, 550, 200, 40);
			
			confirmButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					String nome = nomeField.getText();					
					String texto = buttonsListener.ConfirmaBuscaButtonListener(ADM, CRUD, CATEGORIA, nome);
					TextArea.setText(texto); 
				}
			});
		}
		return confirmButton;
	}
	
	
	public JButton getVoltarButton() {
		if(VoltarButton == null){
			VoltarButton = new JButton("Voltar");
			VoltarButton.setBounds(1000, 20, 150, 30);
			
			VoltarButton.addActionListener(new ActionListener() {				
				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
					@SuppressWarnings("unused") 
					TransicaoFrame transicaoFrame = new TransicaoFrame(ADM, CRUD);
				}
			});
		}
		return VoltarButton;
	}

}