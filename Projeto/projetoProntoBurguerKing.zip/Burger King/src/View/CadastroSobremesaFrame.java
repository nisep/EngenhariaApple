package View;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import Control.ButtonsListener;
import Model.Sobremesa;
import Model.SobremesaDAO;

public class CadastroSobremesaFrame extends JFrame{


	private static final long serialVersionUID = 1L;
	
	private URL UrlBackground;
	private Image Background;
	
	private Boolean ADM;
	private int CRUD;
	@SuppressWarnings("unused")
	private int CATEGORIA;
	@SuppressWarnings("unused")
	private String nome;
	
	private JTextField nomeField;
	private JTextField precoField;
	private JTextField ingredientesField;
	
	private JLabel nomeLabel;
	private JLabel precoLabel;
	private JLabel ingredientesLabel;
	
	private JButton confirmButton;
	private JButton voltarButton;
	
	private ButtonsListener buttonsListener = new ButtonsListener();
	
	private SobremesaDAO sobremesaDAO = new SobremesaDAO("Sobremesas.txt");
	private ArrayList<Sobremesa> sobremesas;
	
	private Font Fonte25 = new Font("SansSerif", Font.PLAIN, 30);
	
	/*    CRUD
	 * 1 => Cadastro
	 * 2 => Editar
	 * 3 => Excluir
	 * 4 => Buscar
	 * 5 => Listar
	 * 6 => Gerar Relat�rio*/
	
	/*  CATEGORIA
	 * 1 => Usuario
	 * 2 => Lanches
	 * 3 => Sobremesa
	 * 4 => Bebida
	 * 5 => Combo
	 * 6 => Promocao */
	
	public CadastroSobremesaFrame(Boolean ADM, int CRUD, int CATEGORIA){

		super();
		
		this.ADM = ADM;
		this.CRUD = CRUD;
		this.CATEGORIA = CATEGORIA;
		
		setSize(1200, 700);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setTitle("Sobremesa - Burger King");
		setResizable(false);
		setVisible(true);
		
		UrlBackground = getClass().getResource("Background.png");
		Background = Toolkit.getDefaultToolkit().getImage(UrlBackground);
	    JLabel background = new JLabel(new ImageIcon(Background));
	    background.setBounds(0, 0, 1200, 700);
	    
	    add(getnomeField());
	    add(getPrecoField());
	    add(getIngredientesField());
	    
	    add(getNomeLabel());
	    add(getPrecoLabel());
	    add(getIngredientesLabel());
	    
	    add(getConfirmButton());
	    add(getVoltarButton());
	    
	    add(background);
		
	}
	
	public CadastroSobremesaFrame(Boolean ADM, int CRUD, int CATEGORIA, String nome){

		super();
		
		this.ADM = ADM;
		this.CRUD = CRUD;
		this.CATEGORIA = CATEGORIA;
		this.nome = nome;
		
		setSize(1200, 700);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setTitle("Sobremesa - Burger King");
		setResizable(false);
		setVisible(true);
		
		UrlBackground = getClass().getResource("Background.png");
		Background = Toolkit.getDefaultToolkit().getImage(UrlBackground);
	    JLabel background = new JLabel(new ImageIcon(Background));
	    background.setBounds(0, 0, 1200, 700);
	    
	    add(getnomeField());
	    add(getPrecoField());
	    add(getIngredientesField());
	    
	    add(getNomeLabel());
	    add(getPrecoLabel());
	    add(getIngredientesLabel());
	    
	    add(getConfirmButton());
	    add(getVoltarButton());
	    
	    add(background);
		
	    sobremesas = sobremesaDAO.read();
	    for(Sobremesa sobremesa : sobremesas) {
	    	if(sobremesa.getNome().equals(nome)) {
	    		nomeField.setText(sobremesa.getNome());
	    		precoField.setText(sobremesa.getPreco());
	    		ingredientesField.setText(sobremesa.getIngredientes());
	    		break;
	    	}
	    }
	}
	
	public JTextField getnomeField(){
		if(nomeField == null) {
			nomeField = new JTextField();
			nomeField.setFont(Fonte25);
			nomeField.setBounds(80, 100, 400, 50);
		}
		return nomeField;
	}
	
	public JTextField getPrecoField(){
		if(precoField == null) {
			precoField = new JTextField();
			precoField.setFont(Fonte25);
			precoField.setBounds(80, 200, 400, 50);
		}
		return precoField;
	}
	
	public JTextField getIngredientesField(){
		if(ingredientesField == null) {
			ingredientesField = new JTextField();
			ingredientesField.setFont(Fonte25);
			ingredientesField.setBounds(80, 300, 400, 50);
		}
		return ingredientesField;
	}
	
	
	public JLabel getNomeLabel() {
		if(nomeLabel == null){
			nomeLabel = new JLabel("Nome:");
			nomeLabel.setForeground(Color.BLACK);
			nomeLabel.setVisible(true);
			nomeLabel.setFont(Fonte25);
			nomeLabel.setBounds(80, 50, 100, 40);
		}
		return nomeLabel;
	}
	
	public JLabel getPrecoLabel() {
		if(precoLabel == null){
			precoLabel = new JLabel("Pre�o:");
			precoLabel.setForeground(Color.BLACK);
			precoLabel.setVisible(true);
			precoLabel.setFont(Fonte25);
			precoLabel.setBounds(80, 150, 100, 40);
		}
		return precoLabel;
	}
	
	public JLabel getIngredientesLabel() {
		if(ingredientesLabel == null){
			ingredientesLabel = new JLabel("Ingredientes:");
			ingredientesLabel.setForeground(Color.BLACK);
			ingredientesLabel.setVisible(true);
			ingredientesLabel.setFont(Fonte25);
			ingredientesLabel.setBounds(80, 250, 400, 40);
		}
		return ingredientesLabel;
	}

	public JButton getConfirmButton(){
		if(confirmButton == null){
			confirmButton = new JButton("Confirmar");
			confirmButton.setFont(Fonte25);
			confirmButton.setBounds(80, 400, 400, 40);
			
			confirmButton.addActionListener(new ActionListener() {				
				@Override
				public void actionPerformed(ActionEvent e) {
					String nome = nomeField.getText();
					String preco = precoField.getText();
					String ingredientes = ingredientesField.getText();
						
					buttonsListener.ConfiemaCadastroSobremesaButtonListener(ADM, nome, preco, ingredientes);
				}
			});
		}
		return confirmButton;
	}
	
	public JButton getVoltarButton() {
		if(voltarButton == null){
			voltarButton = new JButton("Voltar");
			voltarButton.setBounds(1000, 20, 150, 30);
			
			voltarButton.addActionListener(new ActionListener() {				
				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
					@SuppressWarnings("unused") 
					TransicaoFrame transicaoUsuarioFrame = new TransicaoFrame(ADM, CRUD);
				}
			});
		}
		return voltarButton;
	}
}
