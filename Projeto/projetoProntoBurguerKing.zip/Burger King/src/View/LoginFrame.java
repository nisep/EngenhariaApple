package View;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import Control.ButtonsListener;

public class LoginFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	
	private URL UrlBackground;
	private Image Background;
	
	private JLabel loginLabel;
	private JLabel senhaLabel;
	
	private JTextField loginField;
	private JPasswordField senhaField;
	
	private JButton loginButton;
	
	private ButtonsListener buttonsListener = new ButtonsListener();
	
	private Font Fonte25 = new Font("SansSerif", Font.PLAIN, 25);
	
	public LoginFrame() {
		super();
		
		setSize(1200, 700);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setTitle("Login - Burger King");
		setResizable(false);
		setVisible(true);
		
		UrlBackground = getClass().getResource("Background.png");
		Background = Toolkit.getDefaultToolkit().getImage(UrlBackground);
	    JLabel background = new JLabel(new ImageIcon(Background));
	    background.setBounds(0, 0, 1200, 700);
	    
	    getRootPane().setDefaultButton(getLoginButton());
	    
	    add(getSenhaLabel());
	    add(getLoginLabel());
	    
	    add(getLoginField());
	    add(getSenhaField());
	    
	    add(getLoginButton());
	    
	    add(background);
	}
	
	public JButton getLoginButton() {
		if(loginButton == null){
			loginButton = new JButton("Login");
			loginButton.setBounds(160, 480, 200, 40);
			loginButton.setFont(Fonte25);
			
			loginButton.addActionListener(new ActionListener() {
				@SuppressWarnings("deprecation")
				@Override
				public void actionPerformed(ActionEvent arg0) {
					String login = loginField.getText();
					String senha = senhaField.getText();
					buttonsListener.ConfirmaLoginButtonListener(login, senha);
				}
			});
		}
		return loginButton;
	}
	
	public JLabel getLoginLabel() {
		if(loginLabel == null){
			loginLabel = new JLabel("Login");
			loginLabel.setForeground(Color.BLACK);
			loginLabel.setVisible(true);
			loginLabel.setFont(Fonte25);
			loginLabel.setBounds(80, 260, 100, 40);
		}
		return loginLabel;
	}
	
	public JLabel getSenhaLabel() {
		if(senhaLabel == null) {
			senhaLabel = new JLabel("Senha");
			senhaLabel.setForeground(Color.BLACK);
			senhaLabel.setVisible(true);
			senhaLabel.setFont(Fonte25);
			senhaLabel.setBounds(80, 360, 200, 50);
		}
		return senhaLabel;
	}
	
	public JTextField getLoginField() {
		if(loginField == null) {
			loginField = new JTextField();
			loginField.setFont(Fonte25);
			loginField.setBounds(80, 315, 360, 40);
		}
		return loginField;
	}
	
	public JTextField getSenhaField() {
		if(senhaField == null) {
			senhaField = new JPasswordField();
			senhaField.setFont(Fonte25);
			senhaField.setBounds(80, 415, 360, 40);
		}
		return senhaField;
	}

}
