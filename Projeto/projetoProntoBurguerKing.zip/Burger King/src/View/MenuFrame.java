package View;

import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import Control.ButtonsListener;

public class MenuFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	
	private URL UrlBackground;
	private Image Background;
	
	private Boolean ADM;
	
	private JButton CadastrarButton;
	private JButton EditarButton;
	private JButton ExcluirButton;
	private JButton BuscarButton;
	private JButton ListarButton;
	private JButton LogoutButton;
	private JButton RelatorioButton;
	
	private ButtonsListener buttonsListener = new ButtonsListener();
	
	/*    CRUD
	 * 1 => Cadastro
	 * 2 => Editar
	 * 3 => Excluir
	 * 4 => Buscar
	 * 5 => Listar
	 * 6 => Gerar Relat�rio*/
	
	/*  CATEGORIA
	 * 1 => Usuario
	 * 2 => Lanches
	 * 3 => Sobremesa
	 * 4 => Bebida
	 * 5 => Combo
	 * 6 => Promocao */
	
	private Font Fonte25 = new Font("SansSerif", Font.PLAIN, 30);
	
	public MenuFrame(boolean ADM) {
		super();
		
		this.ADM = ADM;
		
		setSize(1200, 700);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setTitle("Menu - Burger King");
		setResizable(false);
		setVisible(true);
		
		UrlBackground = getClass().getResource("Background.png");
		Background = Toolkit.getDefaultToolkit().getImage(UrlBackground);
	    JLabel background = new JLabel(new ImageIcon(Background));
	    background.setBounds(0, 0, 1200, 700);
	    
	    add(getCadastrarButton());
	    add(getEditarButton());
	    add(getExcluirButton());
	    add(getBuscarButton());
	    add(getListarButton());
	    add(getRelatorioButton());
	    
	    add(getLogoutButton());
	    
	    add(background);
	}
	
	public JButton getRelatorioButton() {
		if(RelatorioButton == null) {
			RelatorioButton = new JButton("Gerar Relat�rio");
			RelatorioButton.setBounds(80, 560, 400, 60);
			RelatorioButton.setFont(Fonte25);
			
			RelatorioButton.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					//GERAR PDF
				}
			});
		}
		return RelatorioButton;
	}
	
	
	public JButton getCadastrarButton() {
		if(CadastrarButton == null){
			CadastrarButton = new JButton("Cadastrar");
			CadastrarButton.setBounds(80, 60, 400, 60);
			CadastrarButton.setFont(Fonte25);
			
			CadastrarButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
					buttonsListener.CadastrarButtonListener(ADM);
				}
			});
		}
		return CadastrarButton;
	}
	
	
	public JButton getEditarButton() {
		if(EditarButton == null){
			EditarButton = new JButton("Editar");
			EditarButton.setBounds(80, 160, 400, 60);
			EditarButton.setFont(Fonte25);
			
			EditarButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
					buttonsListener.EditarButtonListener(ADM);
				}
			});
		}
		return EditarButton;
	}
	
	
	public JButton getExcluirButton() {
		if(ExcluirButton == null){
			ExcluirButton = new JButton("Excluir");
			ExcluirButton.setBounds(80, 260, 400, 60);
			ExcluirButton.setFont(Fonte25);
			
			ExcluirButton.addActionListener(new ActionListener() {				
				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
					buttonsListener.ExcluirButtonListener(ADM);
				}
			});
		}
		return ExcluirButton;
	}
	
	
	public JButton getBuscarButton() {
		if(BuscarButton == null){
			BuscarButton = new JButton("Buscar");
			BuscarButton.setBounds(80, 360, 400, 60);
			BuscarButton.setFont(Fonte25);
			
			BuscarButton.addActionListener(new ActionListener() {				
				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
					buttonsListener.BuscarButtonListener(ADM);
				}
			});
		}
		return BuscarButton;
	}
	
	
	public JButton getListarButton() {
		if(ListarButton == null){
			ListarButton = new JButton("Listar");
			ListarButton.setBounds(80, 460, 400, 60);
			ListarButton.setFont(Fonte25);
			
			ListarButton.addActionListener(new ActionListener() {				
				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
					buttonsListener.ListarButtonListener(ADM);
				}
			});
		}
		return ListarButton;
	}
	
	
	public JButton getLogoutButton() {
		if(LogoutButton == null){
			LogoutButton = new JButton("Logout");
			LogoutButton.setBounds(1000, 20, 150, 30);
			
			LogoutButton.addActionListener(new ActionListener() {				
				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
					buttonsListener.LogoutButtonListener();
				}
			});
		}
		return LogoutButton;
	}
}
