package View;

import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class TransicaoFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	
	private URL UrlBackground;
	private Image Background;
	
	private int CRUD;
	
	private Boolean ADM;
	
	private JButton UsuarioButton;
	private JButton LancheButton;
	private JButton SobremesaButton;
	private JButton BebidaButton;
	private JButton ComboButton;
	private JButton PromocaoButton;
	private JButton VoltarButton;
	
	private Font Fonte25 = new Font("SansSerif", Font.PLAIN, 30);
	
	public TransicaoFrame(boolean ADM, int CRUD) {
		super();
		
		this.ADM = ADM;
		this.CRUD = CRUD;
		
		setSize(1200, 700);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setTitle("Burger King");
		setResizable(false);
		setVisible(true);
		
		UrlBackground = getClass().getResource("Background.png");
		Background = Toolkit.getDefaultToolkit().getImage(UrlBackground);
	    JLabel background = new JLabel(new ImageIcon(Background));
	    background.setBounds(0, 0, 1200, 700);
	    
	    add(getUsuarioButton());
	    add(getLancheButton());
	    add(getSobremesaButton());
	    add(getBebidaButton());
	    add(getComboButton());
	    add(getPromocaoButton());
	    
	    add(getVoltarButton());
	    
	    add(background);
	}
	
	
	/*    CRUD
	 * 1 => Cadastro
	 * 2 => Editar
	 * 3 => Excluir
	 * 4 => Buscar
	 * 5 => Listar
	 * 6 => Gerar Relat�rio*/
	
	/*  CATEGORIA
	 * 1 => Usuario
	 * 2 => Lanches
	 * 3 => Sobremesa
	 * 4 => Bebida
	 * 5 => Combo
	 * 6 => Promocao */
	
	
	public JButton getUsuarioButton() {
		if(UsuarioButton == null){
			UsuarioButton = new JButton("Usu�rio");
			UsuarioButton.setBounds(80, 60, 400, 60);
			UsuarioButton.setFont(Fonte25);
			
			UsuarioButton.addActionListener(new ActionListener() {				
				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
					if(CRUD == 1) {@SuppressWarnings("unused") CadastroUsuarioFrame cadastroUsuarioFrame = new CadastroUsuarioFrame(ADM, CRUD, 1);}
					if(CRUD == 2) {@SuppressWarnings("unused") BuscarFrame buscarFrame = new BuscarFrame(ADM, CRUD, 1);}
					if(CRUD == 3) {@SuppressWarnings("unused") BuscarFrame buscarFrame = new BuscarFrame(ADM, CRUD, 1);}
					if(CRUD == 4) {@SuppressWarnings("unused") BuscarFrame buscarFrame = new BuscarFrame(ADM, CRUD, 1);}
					if(CRUD == 5) {@SuppressWarnings("unused") ListagemFrame listagemFrame = new ListagemFrame(ADM, CRUD, 1);}
				}
			});
		}
		return UsuarioButton;
	}
	
	
	public JButton getLancheButton() {
		if(LancheButton == null){
			LancheButton = new JButton("Lanche");
			LancheButton.setBounds(80, 160, 400, 60);
			LancheButton.setFont(Fonte25);
			
			LancheButton.addActionListener(new ActionListener() {				
				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
					if(CRUD == 1) {@SuppressWarnings("unused") CadastroLancheFrame cadastroLancheFrame = new CadastroLancheFrame(ADM, CRUD, 2);}
					if(CRUD == 2) {@SuppressWarnings("unused") BuscarFrame buscarFrame = new BuscarFrame(ADM, CRUD, 2);}
					if(CRUD == 3) {@SuppressWarnings("unused") BuscarFrame buscarFrame = new BuscarFrame(ADM, CRUD, 2);}
					if(CRUD == 4) {@SuppressWarnings("unused") BuscarFrame buscarFrame = new BuscarFrame(ADM, CRUD, 2);}
					if(CRUD == 5) {@SuppressWarnings("unused") ListagemFrame listagemFrame = new ListagemFrame(ADM, CRUD, 2);}
				}
			});
		}
		return LancheButton;
	}
	
	
	public JButton getSobremesaButton() {
		if(SobremesaButton == null){
			SobremesaButton = new JButton("Sobremesa");
			SobremesaButton.setBounds(80, 260, 400, 60);
			SobremesaButton.setFont(Fonte25);
			
			SobremesaButton.addActionListener(new ActionListener() {				
				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
					if(CRUD == 1) {@SuppressWarnings("unused") CadastroSobremesaFrame cadastroSobremesaFrame = new CadastroSobremesaFrame(ADM, CRUD, 3);}
					if(CRUD == 2) {@SuppressWarnings("unused") BuscarFrame buscarFrame = new BuscarFrame(ADM, CRUD, 3);}
					if(CRUD == 3) {@SuppressWarnings("unused") BuscarFrame buscarFrame = new BuscarFrame(ADM, CRUD, 3);}
					if(CRUD == 4) {@SuppressWarnings("unused") BuscarFrame buscarFrame = new BuscarFrame(ADM, CRUD, 3);}
					if(CRUD == 5) {@SuppressWarnings("unused") ListagemFrame listagemFrame = new ListagemFrame(ADM, CRUD, 3);}
				}
			});
		}
		return SobremesaButton;
	}
	
	
	public JButton getBebidaButton() {
		if(BebidaButton == null){
			BebidaButton = new JButton("Bebida");
			BebidaButton.setBounds(80, 360, 400, 60);
			BebidaButton.setFont(Fonte25);
			
			BebidaButton.addActionListener(new ActionListener() {				
				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
					if(CRUD == 1) {@SuppressWarnings("unused") CadastroBebidaFrame cadastroBebidaFrame = new CadastroBebidaFrame(ADM, CRUD, 4);}
					if(CRUD == 2) {@SuppressWarnings("unused") BuscarFrame buscarFrame = new BuscarFrame(ADM, CRUD, 4);}
					if(CRUD == 3) {@SuppressWarnings("unused") BuscarFrame buscarFrame = new BuscarFrame(ADM, CRUD, 4);}
					if(CRUD == 4) {@SuppressWarnings("unused") BuscarFrame buscarFrame = new BuscarFrame(ADM, CRUD, 4);}
					if(CRUD == 5) {@SuppressWarnings("unused") ListagemFrame listagemFrame = new ListagemFrame(ADM, CRUD, 4);}
				}
			});
		}
		return BebidaButton;
	}
	
	
	public JButton getComboButton() {
		if(ComboButton == null){
			ComboButton = new JButton("Combos");
			ComboButton.setBounds(80, 460, 400, 60);
			ComboButton.setFont(Fonte25);
			
			ComboButton.addActionListener(new ActionListener() {				
				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
					if(CRUD == 1) {@SuppressWarnings("unused") CadastroComboFrame cadastroComboFrame = new CadastroComboFrame(ADM, CRUD, 5);}
					if(CRUD == 2) {@SuppressWarnings("unused") BuscarFrame buscarFrame = new BuscarFrame(ADM, CRUD, 5);}
					if(CRUD == 3) {@SuppressWarnings("unused") BuscarFrame buscarFrame = new BuscarFrame(ADM, CRUD, 5);}
					if(CRUD == 4) {@SuppressWarnings("unused") BuscarFrame buscarFrame = new BuscarFrame(ADM, CRUD, 5);}
					if(CRUD == 5) {@SuppressWarnings("unused") ListagemFrame listagemFrame = new ListagemFrame(ADM, CRUD, 5);}
				}
			});
		}
		return ComboButton;
	}
	
	
	public JButton getPromocaoButton() {
		if(PromocaoButton == null){
			PromocaoButton = new JButton("Promo��es");
			PromocaoButton.setBounds(80, 560, 400, 60);
			PromocaoButton.setFont(Fonte25);
			
			PromocaoButton.addActionListener(new ActionListener() {				
				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
					if(CRUD == 1) {@SuppressWarnings("unused") CadastroPromocaoFrame cadastroPromocaoFrame = new CadastroPromocaoFrame(ADM, CRUD, 6);}
					if(CRUD == 2) {@SuppressWarnings("unused") BuscarFrame buscarFrame = new BuscarFrame(ADM, CRUD, 6);}
					if(CRUD == 3) {@SuppressWarnings("unused") BuscarFrame buscarFrame = new BuscarFrame(ADM, CRUD, 6);}
					if(CRUD == 4) {@SuppressWarnings("unused") BuscarFrame buscarFrame = new BuscarFrame(ADM, CRUD, 6);}
					if(CRUD == 5) {@SuppressWarnings("unused") ListagemFrame listagemFrame = new ListagemFrame(ADM, CRUD, 6);}
				}
			});
		}
		return PromocaoButton;
	}
	
	
	public JButton getVoltarButton() {
		if(VoltarButton == null){
			VoltarButton = new JButton("Voltar");
			VoltarButton.setBounds(1000, 20, 150, 30);
			
			VoltarButton.addActionListener(new ActionListener() {				
				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
					@SuppressWarnings("unused") 
					MenuFrame menuFrame = new MenuFrame(ADM);
				}
			});
		}
		return VoltarButton;
	}

}
