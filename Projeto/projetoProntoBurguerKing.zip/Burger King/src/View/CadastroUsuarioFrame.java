package View;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import Control.ButtonsListener;
import Model.Usuario;
import Model.UsuarioDAO;

public class CadastroUsuarioFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	
	private URL UrlBackground;
	private Image Background;
	
	private Boolean ADM;
	private int CRUD;
	@SuppressWarnings("unused")
	private int CATEGORIA;
	@SuppressWarnings("unused")
	private String nome;
	
	private JTextField nomeField;
	private JTextField cpfField;
	private JTextField senhaField;
	private JTextField dataDeNascimentoField;
	private JTextField identificadorField;
	
	private JLabel nomeLabel;
	private JLabel cpfLabel;
	private JLabel senhaLabel;
	private JLabel dataDeNascimentoLabel;
	private JLabel identificacaoLabel;
	
	private JButton confirmButton;
	private JButton voltarButton;
	
	private ButtonsListener buttonsListener = new ButtonsListener();
	
	private UsuarioDAO usuarioDAO = new UsuarioDAO("Usuarios.txt");
	private ArrayList<Usuario> usuarios;
	
	private Font Fonte25 = new Font("SansSerif", Font.PLAIN, 30);
	
	/*    CRUD
	 * 1 => Cadastro
	 * 2 => Editar
	 * 3 => Excluir
	 * 4 => Buscar
	 * 5 => Listar
	 * 6 => Gerar Relat�rio*/
	
	/*  CATEGORIA
	 * 1 => Usuario
	 * 2 => Lanches
	 * 3 => Sobremesa
	 * 4 => Bebida
	 * 5 => Combo
	 * 6 => Promocao */
	
	public CadastroUsuarioFrame(Boolean ADM, int CRUD, int CATEGORIA){
		
		super();
		
		this.ADM = ADM;
		this.CRUD = CRUD;
		this.CATEGORIA = CATEGORIA;
		
		setSize(1200, 700);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setTitle("Usu�rios - Burger King");
		setResizable(false);
		setVisible(true);
		
		UrlBackground = getClass().getResource("Background.png");
		Background = Toolkit.getDefaultToolkit().getImage(UrlBackground);
	    JLabel background = new JLabel(new ImageIcon(Background));
	    background.setBounds(0, 0, 1200, 700);
	    
	    add(getnomeField());
	    add(getcpfField());
	    add(getsenhaField());
	    add(getdataDeNascimentoField());
	    add(getIdentificadorField());
	    
	    add(getNomeLabel());
	    add(getCpfLabel());
	    add(getSenhaLabel());
	    add(getDataDeNascimentoLabel());
	    add(getIdentificacaoLabel());
	    
	    add(getConfirmButton());
	    add(getVoltarButton());
	    
	    add(background);
		
	}
	
	public CadastroUsuarioFrame(Boolean ADM, int CRUD, int CATEGORIA, String nome){
		
		super();
		
		this.ADM = ADM;
		this.CRUD = CRUD;
		this.CATEGORIA = CATEGORIA;
		this.nome = nome;
		
		setSize(1200, 700);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setTitle("Usu�rios - Burger King");
		setResizable(false);
		setVisible(true);
		
		UrlBackground = getClass().getResource("Background.png");
		Background = Toolkit.getDefaultToolkit().getImage(UrlBackground);
	    JLabel background = new JLabel(new ImageIcon(Background));
	    background.setBounds(0, 0, 1200, 700);
	    
	    add(getnomeField());
	    add(getcpfField());
	    add(getsenhaField());
	    add(getdataDeNascimentoField());
	    add(getIdentificadorField());
	    
	    add(getNomeLabel());
	    add(getCpfLabel());
	    add(getSenhaLabel());
	    add(getDataDeNascimentoLabel());
	    add(getIdentificacaoLabel());
	    
	    add(getConfirmButton());
	    add(getVoltarButton());
	    
	    add(background);
	    
	    usuarios = usuarioDAO.read();
	    for(Usuario usuario : usuarios) {
	    	if(usuario.getNome().equals(nome)) {
	    		nomeField.setText(usuario.getNome());
	    		cpfField.setText(usuario.getCpf());
	    		senhaField.setText(usuario.getSenha());
	    		dataDeNascimentoField.setText(usuario.getDataDeNascimento());
	    		identificadorField.setText(usuario.getIdentificacao());
	    		
	    		usuarios.remove(usuario);
	    		usuarioDAO.write(usuarios);
	    		break;
	    	}
	    }
	}
	
	public JTextField getnomeField(){
		if(nomeField == null) {
			nomeField = new JTextField();
			nomeField.setFont(Fonte25);
			nomeField.setBounds(80, 100, 400, 50);
		}
		return nomeField;
	}
	
	public JTextField getcpfField(){
		if(cpfField == null) {
			cpfField = new JTextField();
			cpfField.setFont(Fonte25);
			cpfField.setBounds(80, 200, 400, 50);
		}
		return cpfField;
	}
	
	public JTextField getsenhaField(){
		if(senhaField == null) {
			senhaField = new JTextField();
			senhaField.setFont(Fonte25);
			senhaField.setBounds(80, 300, 400, 50);
		}
		return senhaField;
	}
	
	public JTextField getdataDeNascimentoField(){
		if(dataDeNascimentoField == null) {
			dataDeNascimentoField = new JTextField();
			dataDeNascimentoField.setFont(Fonte25);
			dataDeNascimentoField.setBounds(80, 400, 400, 50);
		}
		return dataDeNascimentoField;
	}
	
	public JTextField getIdentificadorField(){
		if(identificadorField == null) {
			identificadorField = new JTextField();
			identificadorField.setFont(Fonte25);
			identificadorField.setBounds(80, 500, 400, 50);
			identificadorField.setToolTipText("C ou F");
		}
		return identificadorField;
	}
	
	public JLabel getNomeLabel() {
		if(nomeLabel == null){
			nomeLabel = new JLabel("Nome:");
			nomeLabel.setForeground(Color.BLACK);
			nomeLabel.setVisible(true);
			nomeLabel.setFont(Fonte25);
			nomeLabel.setBounds(80, 50, 100, 40);
		}
		return nomeLabel;
	}
	
	public JLabel getCpfLabel() {
		if(cpfLabel == null){
			cpfLabel = new JLabel("CPF:");
			cpfLabel.setForeground(Color.BLACK);
			cpfLabel.setVisible(true);
			cpfLabel.setFont(Fonte25);
			cpfLabel.setBounds(80, 150, 100, 40);
		}
		return cpfLabel;
	}
	
	public JLabel getSenhaLabel() {
		if(senhaLabel == null){
			senhaLabel = new JLabel("Senha:");
			senhaLabel.setForeground(Color.BLACK);
			senhaLabel.setVisible(true);
			senhaLabel.setFont(Fonte25);
			senhaLabel.setBounds(80, 250, 100, 40);
		}
		return senhaLabel;
	}
	
	public JLabel getDataDeNascimentoLabel() {
		if(dataDeNascimentoLabel == null){
			dataDeNascimentoLabel = new JLabel("Data de nascimento:");
			dataDeNascimentoLabel.setForeground(Color.BLACK);
			dataDeNascimentoLabel.setVisible(true);
			dataDeNascimentoLabel.setFont(Fonte25);
			dataDeNascimentoLabel.setBounds(80, 350, 400, 40);
		}
		return dataDeNascimentoLabel;
	}
	
	public JLabel getIdentificacaoLabel() {
		if(identificacaoLabel == null){
			identificacaoLabel = new JLabel("Identifica��o:");
			identificacaoLabel.setForeground(Color.BLACK);
			identificacaoLabel.setVisible(true);
			identificacaoLabel.setFont(Fonte25);
			identificacaoLabel.setBounds(80, 450, 400, 40);
		}
		return identificacaoLabel;
	}
	
	public JButton getConfirmButton(){
		if(confirmButton == null){
			confirmButton = new JButton("Confirmar");
			confirmButton.setFont(Fonte25);
			confirmButton.setBounds(80, 600, 400, 40);
			
			confirmButton.addActionListener(new ActionListener() {				
				@Override
				public void actionPerformed(ActionEvent e) {
					String nome = nomeField.getText();
					String cpf = cpfField.getText();
					String senha = senhaField.getText();
					String dataDeNascimento = dataDeNascimentoField.getText();
					String identificacao = identificadorField.getText();
						
					buttonsListener.ConfirmaCadastroUsuarioButtonListener(ADM, nome, senha, cpf, dataDeNascimento, identificacao);
				}
			});
		}
		return confirmButton;
	}
	
	public JButton getVoltarButton() {
		if(voltarButton == null){
			voltarButton = new JButton("Voltar");
			voltarButton.setBounds(1000, 20, 150, 30);
			
			voltarButton.addActionListener(new ActionListener() {			
				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
					@SuppressWarnings("unused") 
					TransicaoFrame transicaoUsuarioFrame = new TransicaoFrame(ADM, CRUD);
				}
			});
		}
		return voltarButton;
	}

	
}
