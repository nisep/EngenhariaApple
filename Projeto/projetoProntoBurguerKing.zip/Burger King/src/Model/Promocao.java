package Model;

public class Promocao extends Produto {
	
	private String descricao;
	
	public Promocao(String nome, String preco, String descricao) {
		super();
		
		super.setNome(nome);
		super.setPreco(preco);
		this.descricao = descricao;
	}
	
	public Promocao(String line) {
		super();
		
		String[] campos = line.split("@");
		
		super.setNome(campos[0]);
		super.setPreco(campos[1]);
		this.setDescricao(campos[2]);
	}
	
	@Override
	public String toString() {
		return super.toString() + "@" + this.getDescricao();
	}
	
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}
