package Model;

public class Bebida extends Produto {
	
	
	public Bebida(String nome, String preco) {
		super();
		
		super.setNome(nome);
		super.setPreco(preco);
	}
	
	
	public Bebida(String line) {
		super();
		
		String[] campos = line.split("@");
		
		super.setNome(campos[0]);
		super.setPreco(campos[1]);
	}
	
	@Override
	public String toString() {
		return super.toString();
	}
	
}
