package Model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class PromocaoDAO {
	private final String fileName;
	
	public PromocaoDAO(String fileName) {
		this.fileName = fileName;
	}
	
	public void write(ArrayList<Promocao> promocoes) {
		PrintStream ps = null;
        FileOutputStream fos = null;
        File file = new File(fileName);
        file.delete();

        try {
            file.createNewFile();

            fos = new FileOutputStream(file, true);
            ps = new PrintStream(fos);
            
            for(Promocao promocao : promocoes) {
            	ps.println(promocao);
            }
            
        } catch (IOException e) { e.printStackTrace(); }
        finally { if(ps != null) ps.close(); }
	}
	
	public ArrayList<Promocao> read() {
		ArrayList<Promocao> promocoes = null;
		Scanner scanner = null;
		Promocao promocao = null;
		
		try {
			File file = new File(fileName);
			if(file.exists()) {
				promocoes = new ArrayList<Promocao>();
				
				FileInputStream fis = new FileInputStream(file);
                scanner = new Scanner(fis);
                
                while(scanner.hasNextLine()) {
                	String line = scanner.nextLine();
                	promocao = new Promocao(line);
                	promocoes.add(promocao);
                }
			} else return null;
		} catch (FileNotFoundException e) { e.printStackTrace(); }
		finally { if(scanner != null) scanner.close(); }
        return promocoes;
	}
}