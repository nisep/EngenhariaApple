package Model;


public class Combo extends Produto {
	
	private String produtos;
	
	public Combo(String nome, String preco, String produtos) {
		super();
		
		super.setNome(nome);
		super.setPreco(preco);
		this.produtos = produtos;
	}
	
	public Combo(String line) {
		String[] campos = line.split("@");
		
		super.setNome(campos[0]);
		super.setPreco(campos[1]);
		this.setProdutos(campos[2]);
	}
	
	@Override
	public String toString() {
		return super.toString() + "@" + this.getProdutos();
	}
	

	public String getProdutos() {
		return produtos;
	}
	public void setProdutos(String produtos) {
		this.produtos = produtos;
	}
	
}
