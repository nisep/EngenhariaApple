package Model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class LancheDAO {
	private final String fileName;
	
	public LancheDAO(String fileName) {
		this.fileName = fileName;
	}
	
	public void write(ArrayList<Lanche> lanches) {
		PrintStream ps = null;
        FileOutputStream fos = null;
        File file = new File(fileName);
        file.delete();

        try {
            file.createNewFile();

            fos = new FileOutputStream(file, true);
            ps = new PrintStream(fos);
            
            for(Lanche lanche : lanches) {
            	ps.println(lanche);
            }
            
        } catch (IOException e) { e.printStackTrace(); }
        finally { if(ps != null) ps.close(); }
	}
	
	public ArrayList<Lanche> read() {
		ArrayList<Lanche> lanches = null;
		Scanner scanner = null;
		Lanche lanche = null;
		
		try {
			File file = new File(fileName);
			if(file.exists()) {
				lanches = new ArrayList<Lanche>();
				
				FileInputStream fis = new FileInputStream(file);
                scanner = new Scanner(fis);
                
                while(scanner.hasNextLine()) {
                	String line = scanner.nextLine();
                	lanche = new Lanche(line);
                	lanches.add(lanche);
                }
			} else return null;
		} catch (FileNotFoundException e) { e.printStackTrace(); }
		finally { if(scanner != null) scanner.close(); }
        return lanches;
	}
}