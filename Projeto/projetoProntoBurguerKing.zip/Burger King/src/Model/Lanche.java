package Model;


public class Lanche extends Produto {

	private String ingredientes;
	
	public Lanche(String nome, String preco, String ingredientes) {
		super();
		
		super.setNome(nome);
		super.setPreco(preco);
		this.ingredientes = ingredientes;
	}
	
	
	public Lanche(String line) {
		super();
		
		String[] campos = line.split("@");
		
		super.setNome(campos[0]);
		super.setPreco(campos[1]);
		this.setIngredientes(campos[2]);
	}
	
	@Override
	public String toString() {
		return super.toString() + "@" + this.getIngredientes();
	}
	
	public String getIngredientes() {
		return ingredientes;
	}
	public void setIngredientes(String ingredientes) {
		this.ingredientes = ingredientes;
	}
	
}
