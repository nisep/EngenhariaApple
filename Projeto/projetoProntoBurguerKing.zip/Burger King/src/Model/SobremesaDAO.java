package Model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class SobremesaDAO {
	private final String fileName;
	
	public SobremesaDAO(String fileName) {
		this.fileName = fileName;
	}
	
	public void write(ArrayList<Sobremesa> sobremesas) {
		PrintStream ps = null;
        FileOutputStream fos = null;
        File file = new File(fileName);
        file.delete();

        try {
            file.createNewFile();

            fos = new FileOutputStream(file, true);
            ps = new PrintStream(fos);
            
            for(Sobremesa sobremesa : sobremesas) {
            	ps.println(sobremesa);
            }
            
        } catch (IOException e) { e.printStackTrace(); }
        finally { if(ps != null) ps.close(); }
	}
	
	public ArrayList<Sobremesa> read() {
		ArrayList<Sobremesa> sobremesas = null;
		Scanner scanner = null;
		Sobremesa sobremesa = null;
		
		try {
			File file = new File(fileName);
			if(file.exists()) {
				sobremesas = new ArrayList<Sobremesa>();
				
				FileInputStream fis = new FileInputStream(file);
                scanner = new Scanner(fis);
                
                while(scanner.hasNextLine()) {
                	String line = scanner.nextLine();
                	sobremesa = new Sobremesa(line);
                	sobremesas.add(sobremesa);
                }
			} else return null;
		} catch (FileNotFoundException e) { e.printStackTrace(); }
		finally { if(scanner != null) scanner.close(); }
        return sobremesas;
	}
}