package Model;

public class Usuario {

	private String nome;
	private String cpf;
	private String senha;
	private String dataDeNascimento;
	private String identificacao;
	
	public Usuario(String nome, String senha, String cpf, String dataDeNascimento, String identificacao){
		this.nome = nome;
		this.cpf = cpf;
		this.senha = senha;
		this.dataDeNascimento = dataDeNascimento;
		this.identificacao = identificacao;
	}	
	
	public Usuario(String line) {
		String[] campos = line.split("@");
		
		this.setNome(campos[0]);
		this.setCpf(campos[1]);
		this.setSenha(campos[2]);
		this.setDataDeNascimento(campos[3]);
		this.setIdentificacao(campos[4]);
	}
	
	@Override
	public String toString() {
		return this.getNome() + "@" + this.getCpf() + "@" + this.getSenha() + "@" + this.getDataDeNascimento() 
		 + "@" + this.getIdentificacao();
	}
	
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	public String getDataDeNascimento() {
		return dataDeNascimento;
	}
	public void setDataDeNascimento(String dataDeNascimento) {
		this.dataDeNascimento = dataDeNascimento;
	}
	public String getIdentificacao() {
		return identificacao;
	}
	public void setIdentificacao(String identificacao) {
		this.identificacao = identificacao;
	}
	
}
