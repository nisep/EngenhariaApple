package Model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class BebidaDAO {
	private final String fileName;
	
	public BebidaDAO(String fileName) {
		this.fileName = fileName;
	}
	
	public void write(ArrayList<Bebida> bebidas) {
		PrintStream ps = null;
        FileOutputStream fos = null;
        File file = new File(fileName);
        file.delete();

        try {
            file.createNewFile();

            fos = new FileOutputStream(file, true);
            ps = new PrintStream(fos);
            
            for(Bebida bebida : bebidas) {
            	ps.println(bebida);
            }
            
        } catch (IOException e) { e.printStackTrace(); }
        finally { if(ps != null) ps.close(); }
	}
	
	public ArrayList<Bebida> read() {
		ArrayList<Bebida> bebidas = null;
		Scanner scanner = null;
		Bebida bebida = null;
		
		try {
			File file = new File(fileName);
			if(file.exists()) {
				bebidas = new ArrayList<Bebida>();
				
				FileInputStream fis = new FileInputStream(file);
                scanner = new Scanner(fis);
                
                while(scanner.hasNextLine()) {
                	String line = scanner.nextLine();
                	bebida = new Bebida(line);
                	bebidas.add(bebida);
                }
			} else return null;
		} catch (FileNotFoundException e) { e.printStackTrace(); }
		finally { if(scanner != null) scanner.close(); }
        return bebidas;
	}
}
