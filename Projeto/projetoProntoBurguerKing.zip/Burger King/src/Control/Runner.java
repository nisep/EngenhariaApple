package Control;

import View.LoginFrame;

/*    CRUD
 * 1 => Cadastro
 * 2 => Editar
 * 3 => Excluir
 * 4 => Buscar
 * 5 => Listar
 * 6 => Gerar Relat�rio */

/*  CATEGORIA
 * 1 => Usuario
 * 2 => Lanches
 * 3 => Sobremesa
 * 4 => Bebida
 * 5 => Combo
 * 6 => Promocao */

public class Runner {
	
	public static void main(String[] args) {
		
		LoginFrame loginFrame = new LoginFrame();
		loginFrame.setVisible(true);

	}
}