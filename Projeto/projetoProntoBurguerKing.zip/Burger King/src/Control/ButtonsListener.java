package Control;

import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import Model.Bebida;
import Model.BebidaDAO;
import Model.Combo;
import Model.ComboDAO;
import Model.Lanche;
import Model.LancheDAO;
import Model.Promocao;
import Model.PromocaoDAO;
import Model.Sobremesa;
import Model.SobremesaDAO;
import Model.Usuario;
import Model.UsuarioDAO;
import View.CadastroBebidaFrame;
import View.CadastroComboFrame;
import View.CadastroLancheFrame;
import View.CadastroPromocaoFrame;
import View.CadastroSobremesaFrame;
import View.CadastroUsuarioFrame;
import View.LoginFrame;
import View.MenuFrame;
import View.TransicaoFrame;


public class ButtonsListener extends JFrame {
	private static final long serialVersionUID = 1L;
	
	private BebidaDAO bebidaDAO = new BebidaDAO("Bebidas.txt");
	private ComboDAO comboDAO = new ComboDAO("Combos.txt");
	private LancheDAO lancheDAO = new LancheDAO("Lanches.txt");
	private PromocaoDAO promocaoDAO = new PromocaoDAO("Promocoes.txt");
	private SobremesaDAO sobremesaDAO = new SobremesaDAO("Sobremesas.txt");
	private UsuarioDAO usuarioDAO = new UsuarioDAO("Usuarios.txt");
	
	private ArrayList<Bebida> bebidas;
	private ArrayList<Combo> combos;
	private ArrayList<Lanche> lanches;
	private ArrayList<Promocao> promocoes;
	private ArrayList<Sobremesa> sobremesas;
	private ArrayList<Usuario> usuarios;
	
	/*  BUTTONS LISTENER MENUFRAME  */
	
	public void CadastrarButtonListener(boolean ADM) {
		if(ADM) { @SuppressWarnings("unused") TransicaoFrame transicaoFrame = new TransicaoFrame(ADM, 1); }
		else { JOptionPane.showMessageDialog(null, "Voc� n�o possui permiss�o para isto !" ,"Menu - Burger King",JOptionPane.WARNING_MESSAGE);}
	}
	
	public void EditarButtonListener(boolean ADM) {
		if(ADM) { @SuppressWarnings("unused") TransicaoFrame transicaoFrame = new TransicaoFrame(ADM, 2); }
		else { JOptionPane.showMessageDialog(null, "Voc� n�o possui permiss�o para isto !" ,"Menu - Burger King",JOptionPane.WARNING_MESSAGE);}
	}
	
	public void ExcluirButtonListener(boolean ADM) {
		if(ADM) { @SuppressWarnings("unused") TransicaoFrame transicaoFrame = new TransicaoFrame(ADM, 3); }
		else { JOptionPane.showMessageDialog(null, "Voc� n�o possui permiss�o para isto !" ,"Menu - Burger King",JOptionPane.WARNING_MESSAGE);}
	}
	
	public void BuscarButtonListener(boolean ADM) {
		@SuppressWarnings("unused")
		TransicaoFrame transicaoFrame = new TransicaoFrame(ADM, 4);
	}
	
	public void ListarButtonListener(boolean ADM) {
		@SuppressWarnings("unused")
		TransicaoFrame transicaoFrame = new TransicaoFrame(ADM, 5);
	}
	
	public void LogoutButtonListener() {
		@SuppressWarnings("unused") 
		LoginFrame loginFrame = new LoginFrame();
	}
	
	
	/*   BUTTONS LISTENER BUSCARFRAME   */
	
	public String ConfirmaBuscaButtonListener(boolean ADM, int CRUD, int CATEGORIA, String nome) {
		String texto = "";
		Boolean encontrado = false;
				
		if(CRUD == 4) { //Buscar
			
			if(CATEGORIA == 1 && ADM == false) {  //Usu�rios sem permiss�o
				JOptionPane.showMessageDialog(null, "Voc� n�o possui permiss�o para isto !" ,"Listagem - Burger King",JOptionPane.WARNING_MESSAGE);
			}
			if(CATEGORIA == 1 && ADM == true) {  //Usuarios
				usuarios = usuarioDAO.read();
				for(Usuario usuario : usuarios) {
					if(usuario.getNome().equals(nome)) {
						encontrado = true;
						texto += "Nome: " + usuario.getNome() + "\n" + 
								 "CPF: " + usuario.getCpf() + "\n" + 
								 "Senha: " + usuario.getSenha() + "\n" +
								 "Nascimento: " + usuario.getDataDeNascimento() + "\n";
						if(usuario.getIdentificacao().equals("C")) {texto += "ID: Cliente";}
						if(usuario.getIdentificacao().equals("F")) {texto += "ID: Funcion�rio";}
					}
				}
				if(encontrado == false) {JOptionPane.showMessageDialog(null, "Nada encontrado !" ,"Burger King",JOptionPane.WARNING_MESSAGE);}
			}
			if(CATEGORIA == 2) {  //Lanches
				lanches = lancheDAO.read();
				for(Lanche lanche : lanches) {
					if(lanche.getNome().equals(nome)) {
						encontrado = true;
						texto += "Nome: " + lanche.getNome() + "\n" + 
					             "Pre�o: " + lanche.getPreco() + "\n" +
								 "Ingredientes: " + lanche.getIngredientes();
					}						
				}
				if(encontrado == false) {JOptionPane.showMessageDialog(null, "Nada encontrado !" ,"Burger King",JOptionPane.WARNING_MESSAGE);}
			}
			if(CATEGORIA == 3) {  //Sobremesas
				sobremesas = sobremesaDAO.read();
				for(Sobremesa sobremesa : sobremesas) { 
					if(sobremesa.getNome().equals(nome)) {
						encontrado = true;
						texto += "Nome: " + sobremesa.getNome() + "\n" +
					             "Pre�o: " + sobremesa.getPreco() + "\n" +
								 "Ingredientes: " + sobremesa.getIngredientes();
					}
				}
				if(encontrado == false) {JOptionPane.showMessageDialog(null, "Nada encontrado !" ,"Burger King",JOptionPane.WARNING_MESSAGE);}
			}
			if(CATEGORIA == 4) {  //Bebidas
				bebidas = bebidaDAO.read();
				for(Bebida bebida : bebidas) {
					encontrado = true;
					if(bebida.getNome().equals(nome)) {
						texto += "Nome: " + bebida.getNome() + "\n" +
					             "Pre�o: " + bebida.getPreco();
					}
				}
				if(encontrado == false) {JOptionPane.showMessageDialog(null, "Nada encontrado !" ,"Burger King",JOptionPane.WARNING_MESSAGE);}
			}
			if(CATEGORIA == 5) {  //Combos
				combos = comboDAO.read();
				for(Combo combo : combos) { 
					if(combo.getNome().equals(nome)) {
						encontrado = true;
						texto += "Nome: " + combo.getNome() + "\n" +
					             "Pre�o: " + combo.getPreco() + "\n" +
								 "Produtos: " + combo.getProdutos();
					}
				}
				if(encontrado == false) {JOptionPane.showMessageDialog(null, "Nada encontrado !" ,"Burger King",JOptionPane.WARNING_MESSAGE);}
			}
			if(CATEGORIA == 6) {  //Promocoes
				promocoes = promocaoDAO.read();
				for(Promocao promocao : promocoes) { 
					if(promocao.getNome().equals(nome)) {
						encontrado = true;
						texto += "Nome: " + promocao.getNome() + "\n" +
					             "Pre�o: " + promocao.getPreco() + "\n" +
								 "Descri��o: " + promocao.getDescricao();
					}
				}
				if(encontrado == false) {JOptionPane.showMessageDialog(null, "Nada encontrado !" ,"Burger King",JOptionPane.WARNING_MESSAGE);}
			}
			return texto;
		}
		if(CRUD == 2) { //Editar						
			if(CATEGORIA == 1 && ADM == false) {  //Usu�rios sem permiss�o
				JOptionPane.showMessageDialog(null, "Voc� n�o possui permiss�o para isto !" ,"Burger King",JOptionPane.WARNING_MESSAGE);
			}
			if(CATEGORIA == 1 && ADM == true) {  //Usuarios
				usuarios = usuarioDAO.read();
				for(Usuario usuario : usuarios) {
					if(usuario.getNome().equals(nome)) {
						encontrado = true;
						dispose();
						@SuppressWarnings("unused")
						CadastroUsuarioFrame cadastroUsuarioFrame = new CadastroUsuarioFrame(ADM, CRUD, CATEGORIA, nome);
						break;
					}
				}
				if(encontrado == false) {JOptionPane.showMessageDialog(null, "Nada encontrado !" ,"Burger King",JOptionPane.WARNING_MESSAGE);}
			}
			if(CATEGORIA == 2) {  //Lanches
				lanches = lancheDAO.read();
				for(Lanche lanche : lanches) {
					if(lanche.getNome().equals(nome)) {
						encontrado = true;
						dispose();
						@SuppressWarnings("unused")
						CadastroLancheFrame cadastroLancheFrame = new CadastroLancheFrame(ADM, CRUD, CATEGORIA, nome);
						break;
					}							
				}
				if(encontrado == false) {JOptionPane.showMessageDialog(null, "Nada encontrado !" ,"Burger King",JOptionPane.WARNING_MESSAGE);}
			}
			if(CATEGORIA == 3) {  //Sobremesas
				sobremesas = sobremesaDAO.read();
				for(Sobremesa sobremesa : sobremesas) { 
					if(sobremesa.getNome().equals(nome)) {
						encontrado = true;
						dispose();
						@SuppressWarnings("unused")
						CadastroSobremesaFrame cadastroSobremesaFrame = new CadastroSobremesaFrame(ADM, CRUD, CATEGORIA, nome);
						break;
					}
				}
				if(encontrado == false) {JOptionPane.showMessageDialog(null, "Nada encontrado !" ,"Burger King",JOptionPane.WARNING_MESSAGE);}
			}
			if(CATEGORIA == 4) {  //Bebidas
				bebidas = bebidaDAO.read();
				for(Bebida bebida : bebidas) { 
					if(bebida.getNome().equals(nome)) {
						encontrado = true;
						dispose();
						@SuppressWarnings("unused")
						CadastroBebidaFrame cadastroBebidaFrame = new CadastroBebidaFrame(ADM, CRUD, CATEGORIA, nome);
						break;
					}
				}
				if(encontrado == false) {JOptionPane.showMessageDialog(null, "Nada encontrado !" ,"Burger King",JOptionPane.WARNING_MESSAGE);}
			}
			if(CATEGORIA == 5) {  //Combos
				combos = comboDAO.read();
				for(Combo combo : combos) { 
					if(combo.getNome().equals(nome)) {
						encontrado = true;
						dispose();
						@SuppressWarnings("unused")
						CadastroComboFrame cadastroComboFrame = new CadastroComboFrame(ADM, CRUD, CATEGORIA, nome);
						break;
					}
				}
				if(encontrado == false) {JOptionPane.showMessageDialog(null, "Nada encontrado !" ,"Burger King",JOptionPane.WARNING_MESSAGE);}
			}
			if(CATEGORIA == 6) {  //Promocoes
				promocoes = promocaoDAO.read();
				for(Promocao promocao : promocoes) { 
					if(promocao.getNome().equals(nome)) {
						encontrado = true;
						dispose();
						@SuppressWarnings("unused")
						CadastroPromocaoFrame cadastroPromocaoFrame = new CadastroPromocaoFrame(ADM, CRUD, CATEGORIA, nome);
						break;
					}
				}
				if(encontrado == false) {JOptionPane.showMessageDialog(null, "Nada encontrado !" ,"Burger King",JOptionPane.WARNING_MESSAGE);}
			}
		}
		if(CRUD == 3) { //Excluir
			
			if(CATEGORIA == 1 && ADM == false) {  //Usu�rios sem permiss�o
				JOptionPane.showMessageDialog(null, "Voc� n�o possui permiss�o para isto !" ,"Burger King",JOptionPane.WARNING_MESSAGE);
			}
			if(CATEGORIA == 1 && ADM == true) {  //Usuarios
				usuarios = usuarioDAO.read();
				for(Usuario usuario : usuarios) {
					if(usuario.getNome().equals(nome)) {
						encontrado = true;
						texto += "Nome: " + usuario.getNome() + "\n" + 
								 "CPF: " + usuario.getCpf() + "\n" + 
								 "Senha: " + usuario.getSenha() + "\n" +
								 "Nascimento: " + usuario.getDataDeNascimento() + "\n" +
								 "ID: " + usuario.getIdentificacao();
						usuarios.remove(usuario);
						break;
					}
				}
				if(encontrado == true) {JOptionPane.showMessageDialog(null, "Usu�rio Exlcuido com sucesso !" ,"Burger King",JOptionPane.INFORMATION_MESSAGE);}
				if(encontrado == false) {JOptionPane.showMessageDialog(null, "Nada encontrado !" ,"Burger King",JOptionPane.WARNING_MESSAGE);}
				usuarioDAO.write(usuarios);
				dispose();
				@SuppressWarnings("unused")
				MenuFrame menu = new MenuFrame(ADM);
			}
			if(CATEGORIA == 2) {  //Lanches
				lanches = lancheDAO.read();
				for(Lanche lanche : lanches) {
					if(lanche.getNome().equals(nome)) {
						encontrado = true;
						texto += "Nome: " + lanche.getNome() + "\n" + 
					             "Pre�o: " + lanche.getPreco() + "\n" +
								 "Ingredientes: " + lanche.getIngredientes();
						lanches.remove(lanche);
						break;
					}							
				}
				if(encontrado == true) {JOptionPane.showMessageDialog(null, "Lanche Exlcuido com sucesso !" ,"Burger King",JOptionPane.INFORMATION_MESSAGE);}
				if(encontrado == false) {JOptionPane.showMessageDialog(null, "Nada encontrado !" ,"Burger King",JOptionPane.WARNING_MESSAGE);}
				lancheDAO.write(lanches);
				dispose();
				@SuppressWarnings("unused")
				MenuFrame menu = new MenuFrame(ADM);
			}
			if(CATEGORIA == 3) {  //Sobremesas
				sobremesas = sobremesaDAO.read();
				for(Sobremesa sobremesa : sobremesas) { 
					if(sobremesa.getNome().equals(nome)) {
						encontrado = true;
						texto += "Nome: " + sobremesa.getNome() + "\n" +
					             "Pre�o: " + sobremesa.getPreco() + "\n" +
								 "Ingredientes: " + sobremesa.getIngredientes();
						sobremesas.remove(sobremesa);
						break;
					}
				}
				if(encontrado == true) {JOptionPane.showMessageDialog(null, "Sobremesa Exlcuido com sucesso !" ,"Burger King",JOptionPane.INFORMATION_MESSAGE);}
				if(encontrado == false) {JOptionPane.showMessageDialog(null, "Nada encontrado !" ,"Burger King",JOptionPane.WARNING_MESSAGE);}
				sobremesaDAO.write(sobremesas);
				dispose();
				@SuppressWarnings("unused")
				MenuFrame menu = new MenuFrame(ADM);
			}
			if(CATEGORIA == 4) {  //Bebidas
				bebidas = bebidaDAO.read();
				for(Bebida bebida : bebidas) { 
					if(bebida.getNome().equals(nome)) {
						encontrado = true;
						texto += "Nome: " + bebida.getNome() + "\n" +
					             "Pre�o: " + bebida.getPreco();
						bebidas.remove(bebida);
						break;
					}
				}
				if(encontrado == true) {JOptionPane.showMessageDialog(null, "Bebida Exlcuido com sucesso !" ,"Burger King",JOptionPane.INFORMATION_MESSAGE);}
				if(encontrado == false) {JOptionPane.showMessageDialog(null, "Nada encontrado !" ,"Burger King",JOptionPane.WARNING_MESSAGE);}
				bebidaDAO.write(bebidas);
				dispose();
				@SuppressWarnings("unused")
				MenuFrame menu = new MenuFrame(ADM);
			}
			if(CATEGORIA == 5) {  //Combos
				combos = comboDAO.read();
				for(Combo combo : combos) { 
					if(combo.getNome().equals(nome)) {
						encontrado = true;
						texto += "Nome: " + combo.getNome() + "\n" +
					             "Pre�o: " + combo.getPreco() + "\n" +
								 "Produtos: " + combo.getProdutos();
						combos.remove(combo);
						break;
					}
				}
				if(encontrado == true) {JOptionPane.showMessageDialog(null, "Combo Exlcuido com sucesso !" ,"Burger King",JOptionPane.INFORMATION_MESSAGE);}
				if(encontrado == false) {JOptionPane.showMessageDialog(null, "Nada encontrado !" ,"Burger King",JOptionPane.WARNING_MESSAGE);}
				comboDAO.write(combos);
				dispose();
				@SuppressWarnings("unused")
				MenuFrame menu = new MenuFrame(ADM);
			}
			if(CATEGORIA == 6) {  //Promocoes
				promocoes = promocaoDAO.read();
				for(Promocao promocao : promocoes) { 
					if(promocao.getNome().equals(nome)) {
						encontrado = true;
						texto += "Nome: " + promocao.getNome() + "\n" +
					             "Pre�o: " + promocao.getPreco() + "\n" +
								 "Descri��o: " + promocao.getDescricao();
						promocoes.remove(promocao);
						break;
					}
				}
				if(encontrado == true) {JOptionPane.showMessageDialog(null, "Combo Promoc�o com sucesso !" ,"Burger King",JOptionPane.INFORMATION_MESSAGE);}
				if(encontrado == false) {JOptionPane.showMessageDialog(null, "Nada encontrado !" ,"Burger King",JOptionPane.WARNING_MESSAGE);}
				promocaoDAO.write(promocoes);
				dispose();
				@SuppressWarnings("unused")
				MenuFrame menu = new MenuFrame(ADM);
			}
		}
		return texto;
	}
	
	
	/*   BUTTONS LISTENER CADASTROBEBIDAFRAME   */
	
	public void ConfirmaCadastroBebidaButtonListener(boolean ADM, String nome, String preco) {
		Bebida bebida = new Bebida(nome, preco);
		
		bebidas = bebidaDAO.read();
		bebidas.add(bebida);
		bebidaDAO.write(bebidas);
			
		JOptionPane.showMessageDialog(null, "Bebida cadastrada com sucesso !" ,"Cadastro - Burger King",JOptionPane.INFORMATION_MESSAGE);
		dispose();
		@SuppressWarnings("unused")
		MenuFrame menuFrame = new MenuFrame(ADM);
	}
	
	
	/*   BUTTONS LISTENER CADASTROBEBIDAFRAME   */
	
	public void ConfirmaCadastroComboButtonListener(boolean ADM, String nome, String preco, String produtos) {
		Combo combo = new Combo(nome, preco, produtos);
		
		combos = comboDAO.read();
		combos.add(combo);
		comboDAO.write(combos);
			
		JOptionPane.showMessageDialog(null, "Combo cadastrado com sucesso !" ,"Cadastro - Burger King",JOptionPane.INFORMATION_MESSAGE);
		dispose();
		@SuppressWarnings("unused")
		MenuFrame menuFrame = new MenuFrame(ADM);
	}
	
	
	/*   BUTTONS LISTENER CADASTROLANCHEFRAME   */
	
	public void ConfirmaCadastroLancheButtonListener(boolean ADM, String nome, String preco, String ingredientes) {
		Lanche lanche = new Lanche(nome, preco, ingredientes);
		
		lanches = lancheDAO.read();
		lanches.add(lanche);
		lancheDAO.write(lanches);
			
		JOptionPane.showMessageDialog(null, "Lanche cadastrado com sucesso !" ,"Cadastro - Burger King",JOptionPane.INFORMATION_MESSAGE);
		dispose();
		@SuppressWarnings("unused")
		MenuFrame menuFrame = new MenuFrame(ADM);
	}
	
	
	/*   BUTTONS LISTENER CADASTROPROMOCAOFRAME   */
	
	public void ConfirmaCadastroPromocaoButtonListener(boolean ADM, String nome, String preco, String descricao) {
		Promocao promocao = new Promocao(nome, preco, descricao);
		
		promocoes = promocaoDAO.read();
		promocoes.add(promocao);
		promocaoDAO.write(promocoes);
			
		JOptionPane.showMessageDialog(null, "Promocao cadastrado com sucesso !" ,"Cadastro - Burger King",JOptionPane.INFORMATION_MESSAGE);
		dispose();
		@SuppressWarnings("unused")
		MenuFrame menuFrame = new MenuFrame(ADM);
	}
	
	
	/*   BUTTONS LISTENER CADASTRARSOBREMESAFRAME   */
	
	public void ConfiemaCadastroSobremesaButtonListener(boolean ADM, String nome, String preco, String ingredientes) {
		Sobremesa sobremesa = new Sobremesa(nome, preco, ingredientes);
		
		sobremesas = sobremesaDAO.read();
		sobremesas.add(sobremesa);
		sobremesaDAO.write(sobremesas);
			
		JOptionPane.showMessageDialog(null, "Sobremesa cadastrado com sucesso !" ,"Cadastro - Burger King",JOptionPane.INFORMATION_MESSAGE);
		dispose();
		@SuppressWarnings("unused")
		MenuFrame menuFrame = new MenuFrame(ADM);
	}
	
	
	/*   BUTTONS LISTENER CADASTROUSUARIOFRAME   */
	
	public void ConfirmaCadastroUsuarioButtonListener(boolean ADM, String nome, String senha, String cpf, String dataDeNascimento, String identificacao) {
		Usuario usuario = new Usuario(nome, senha, cpf, dataDeNascimento, identificacao);
		
		usuarios = usuarioDAO.read();
		usuarios.add(usuario);
		usuarioDAO.write(usuarios);
			
		JOptionPane.showMessageDialog(null, "Usu�rio cadastrado com sucesso !" ,"Cadastro - Burger King",JOptionPane.INFORMATION_MESSAGE);
		dispose();
		@SuppressWarnings("unused")
		MenuFrame menuFrame = new MenuFrame(ADM);
	}
	
	
	/*   BUTTONS LISTENER LOGINFRAME   */
	
	public void ConfirmaLoginButtonListener(String login, String senha) {
		Boolean encontrado = false;
		
		usuarios = usuarioDAO.read();
		
		for(Usuario usuario : usuarios) {
			if(login.equals(usuario.getNome()) && senha.equals(usuario.getSenha())) {
				encontrado = true;
				if(usuario.getIdentificacao().equals("F")) {
					super.dispose();
					@SuppressWarnings("unused")
					MenuFrame menuFrame = new MenuFrame(true);
					break;
				}
				if(usuario.getIdentificacao().equals("C")) {
					super.dispose();
					@SuppressWarnings("unused")
					MenuFrame menuFrame = new MenuFrame(false);
					break;
				}
			}
		}
		
		if(encontrado == false) {
			JOptionPane.showMessageDialog(null, "Usu�rio ou senha incorreto !" ,"Login - Burger King",JOptionPane.ERROR_MESSAGE);
		}
	}

}